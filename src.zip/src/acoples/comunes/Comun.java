/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acoples.comunes;

import acoples.clases.Proyecto;
import acoples.visual.Lista_vigas_fichero;
import acoples.visual.NewMDIApplication;
import acoples.visual.Nombrar_pryecto;
import acoples.visual.Ventana_calculo;

/**
 *
 * @author Alba Proyecto
 */
public class Comun {
    
    //public static NewMDIApplication nm=new NewMDIApplication();
    public static Proyecto py =new Proyecto();
    //public static Nombrar_pryecto np = new Nombrar_pryecto();
    //public static Ventana_calculo vc=new Ventana_calculo();    
    public static NewMDIApplication nm=new NewMDIApplication();
    //public static Lista_vigas_fichero lv=new Lista_vigas_fichero();
}
